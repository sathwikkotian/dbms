# vtu-dbms-lab

These files are part of the **VTU DBMS Lab Tutorial** offered at [kaliyona.com](https://www.kaliyona.com)

Please enroll for the course and upon succesful completion you will be receiving a course completion certificate.

Course Link: [Click Here](https://kaliyona.com/courses/vtu-dbms-lab/)

Course Author: **Prathima Deepak**
